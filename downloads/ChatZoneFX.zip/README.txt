ChatZoneFX

## Como abrir no Windows

1. Instale o Java 17 ou superior.
2. Extraia este ZIP.
3. Dê duplo clique em `abrir-windows.bat`.

## Como abrir no Linux/macOS

Execute `./abrir-linux-macos.sh` no terminal.

## Configuração opcional

O cliente usa localhost por padrão. Para apontar para outro servidor,
configure CHAT_SERVER_HOST, CHAT_SERVER_PORT_BASE e CHAT_SERVER_HTTP_URL.
