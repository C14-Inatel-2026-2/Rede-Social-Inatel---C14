ChatZoneFX

## Antes de abrir o cliente

O chat precisa do servidor e do banco rodando. Com o Docker instalado,
abra um terminal na pasta servidor e execute:

    docker compose up -d --build

Confira em http://localhost:8089/rooms se as salas aparecem.

## Como abrir no Windows

1. Instale o Java 17 ou superior.
2. Extraia este ZIP.
3. Dê duplo clique em `abrir-windows.bat`.

## Como abrir no Linux/macOS

Execute `./abrir-linux-macos.sh` no terminal.

## Configuração opcional

O cliente usa localhost por padrão. Para apontar para outro servidor,
configure CHAT_SERVER_HOST, CHAT_SERVER_PORT_BASE e CHAT_SERVER_HTTP_URL.
