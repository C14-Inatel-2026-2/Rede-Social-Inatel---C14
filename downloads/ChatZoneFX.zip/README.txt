ChatZoneFX

Requisitos: Java 17 ou superior.

Para executar no Windows, abra um terminal nesta pasta e rode:
  java --module-path lib --add-modules javafx.controls,javafx.fxml -cp "ChatZoneFX.jar;lib/*" chatzone.Main

Configure as variaveis DB_URL, DB_USER, DB_PASSWORD,
CHAT_SERVER_HOST, CHAT_SERVER_PORT_BASE e CHAT_SERVER_HTTP_URL
antes de iniciar o cliente.
