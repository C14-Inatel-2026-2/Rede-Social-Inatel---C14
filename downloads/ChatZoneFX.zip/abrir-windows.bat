@echo off
cd /d "%~dp0"
where java >nul 2>&1 || (
  echo Java nao foi encontrado. Instale o Java 17 ou superior.
  pause
  exit /b 1
)
java --module-path lib --add-modules javafx.controls,javafx.fxml -cp "ChatZoneFX.jar;lib/*" chatzone.Main
if errorlevel 1 pause
