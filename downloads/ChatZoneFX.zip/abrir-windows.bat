@echo off
cd /d "%~dp0"
if not defined DB_URL set "DB_URL=jdbc:mysql://localhost:3307/db"
if not defined DB_USER set "DB_USER=redesocial"
if not defined DB_PASSWORD set "DB_PASSWORD=redesocial"
where java >nul 2>&1 || (
  echo Java nao foi encontrado. Instale o Java 17 ou superior.
  pause
  exit /b 1
)
java --module-path lib-windows --add-modules javafx.controls,javafx.fxml -cp "ChatZoneFX.jar;lib/*" chatzone.Main
if errorlevel 1 pause
