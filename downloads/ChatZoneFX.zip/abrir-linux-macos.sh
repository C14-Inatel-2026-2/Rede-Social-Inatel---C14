#!/usr/bin/env sh
cd "$(dirname "$0")"
export DB_URL="${DB_URL:-jdbc:mysql://localhost:3307/db}"
export DB_USER="${DB_USER:-redesocial}"
export DB_PASSWORD="${DB_PASSWORD:-redesocial}"
command -v java >/dev/null 2>&1 || { echo "Java 17 ou superior nao foi encontrado."; exit 1; }
exec java --module-path lib --add-modules javafx.controls,javafx.fxml -cp "ChatZoneFX.jar:lib/*" chatzone.Main
