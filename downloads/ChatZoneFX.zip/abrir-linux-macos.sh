#!/usr/bin/env sh
cd "$(dirname "$0")"
command -v java >/dev/null 2>&1 || { echo "Java 17 ou superior nao foi encontrado."; exit 1; }
exec java --module-path lib --add-modules javafx.controls,javafx.fxml -cp "ChatZoneFX.jar:lib/*" chatzone.Main
